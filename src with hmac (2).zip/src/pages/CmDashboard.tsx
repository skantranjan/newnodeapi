import React, { useState, useEffect, useMemo } from 'react';
import Layout from '../components/Layout';
import MultiSelect from '../components/MultiSelect';
import Pagination from '../components/Pagination';
import * as XLSX from 'xlsx';
import { Link, useNavigate } from 'react-router-dom';
import Loader from '../components/Loader';
import { useMsal } from '@azure/msal-react';
import { apiGet, apiPost, apiPatch } from '../utils/api';



const ComingSoon: React.FC = () => {
  return (
    <div style={containerStyle}>
      <h1 style={headingStyle}>Coming Soon</h1>
      <p style={textStyle}>
        This page will be available soon. Thank you for your patience.
      </p>
    </div>
  );
};

const containerStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  height: '100vh',
  backgroundColor: '#f5f7fa',
  fontFamily: 'Segoe UI, sans-serif',
  textAlign: 'center',
  padding: '0 20px',
};

const headingStyle: React.CSSProperties = {
  fontSize: '2.5rem',
  color: '#2c3e50',
  marginBottom: '1rem',
};

const textStyle: React.CSSProperties = {
  fontSize: '1.2rem',
  color: '#555',
  maxWidth: '600px',
};

export default ComingSoon;